package com.example.mariogp18.tanga;

/**
 * Created by mariogp18 on 11/4/15.
 */

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.example.mariogp18.tanga.app.AppController;
import com.example.mariogp18.tanga.model.Tanga;

import java.util.List;

public class CustomListAdapter extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<Tanga> tangasItems;
    ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    public CustomListAdapter(Activity activity, List<Tanga> tangaItems) {
        this.activity = activity;
        this.tangasItems = tangaItems;
    }

    @Override
    public int getCount() {
        return tangasItems.size();
    }

    @Override
    public Object getItem(int location) {
        return tangasItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.list_row, null);

        if (imageLoader == null)
            imageLoader = AppController.getInstance().getImageLoader();
        NetworkImageView thumbNail = (NetworkImageView) convertView
                .findViewById(R.id.thumbnail);

        //Set Name, Price, msrpPrice, and Product URL into TextView
        TextView name = (TextView) convertView.findViewById(R.id.name);
        TextView price = (TextView) convertView.findViewById(R.id.price);
        TextView msrpPrice = (TextView) convertView.findViewById(R.id.msrpPrice);
        TextView productUrl = (TextView) convertView.findViewById(R.id.productUrl);

        //Getting Tanga data for the row
        Tanga m = tangasItems.get(position);

        //Thumbnail image
        thumbNail.setImageUrl(m.getThumbnailUrl(), imageLoader);

        //Title
        name.setText(m.getName());

        //Price
        price.setText("$" + String.valueOf(m.getPrice()));

        //MSRP
        msrpPrice.setPaintFlags(msrpPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        msrpPrice.setText("$" + String.valueOf(m.getMsrpPrice()));

        //Product URL
        productUrl.setText(m.getProductUrl());

        return convertView;
    }
}