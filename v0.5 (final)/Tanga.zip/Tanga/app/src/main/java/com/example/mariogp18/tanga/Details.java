package com.example.mariogp18.tanga;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * Created by mariogp18 on 11/5/15.
 */
public class Details extends ActionBarActivity {

    private static String Title2 = "title2";
    Toolbar toolbar;
    private WebView web;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);

        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);

        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.abc_ic_ab_back_mtrl_am_alpha);
        upArrow.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);

        Intent i = getIntent();
        String url = i.getStringExtra(Title2);

        web = (WebView) findViewById(R.id.myWebView);

        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setUserAgentString("shoptanga");

        final Activity activity = this;

        web.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }
        });

        web.loadUrl(url);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (web.canGoBack()) {
                        overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
                        web.goBack();

                    } else {
                        finish();
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);

                return true;

            default:
                overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
            overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
            return;
        }

        // Otherwise defer to system default behavior.
        overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);

        super.onBackPressed();
//        overridePendingTransition(R.anim.abc_slide_in_bottom, R.anim.abc_slide_in_top);


    }
}