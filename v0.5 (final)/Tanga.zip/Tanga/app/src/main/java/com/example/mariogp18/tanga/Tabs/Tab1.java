package com.example.mariogp18.tanga.Tabs;

/**
 * Created by mariogp18 on 10/18/15.
 */

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.example.mariogp18.tanga.CustomListAdapter;
import com.example.mariogp18.tanga.Details;
import com.example.mariogp18.tanga.R;
import com.example.mariogp18.tanga.app.AppController;
import com.example.mariogp18.tanga.model.Tanga;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class Tab1 extends Fragment {

    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Calendar cal = Calendar.getInstance();
    String date = dateFormat.format(cal.getTime());
    String updateUrl = "https://www.tanga.com/deals/front-page-for-" + date + ".json";

    private final String url = updateUrl;
    private List<Tanga> tangaList = new ArrayList<Tanga>();
    private ListView listView;
    private CustomListAdapter adapter;
    private static String Title2 = "title2";


    private ProgressDialog progressDialog;

    public Tab1() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onActivityCreated (Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);

        listView = (ListView) getView().findViewById(R.id.list);
        adapter = new CustomListAdapter(getActivity(), tangaList);
        listView.setAdapter(adapter);
        JsonArrayRequest tangaReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Parsing json
                        for (int i = 0; i < response.length(); i++) {
                            try {

                                JSONObject obj = response.getJSONObject(i);
                                Tanga tanga = new Tanga();

                                //name
                                String name = obj.getString("name");
                                tanga.setName(name);
                                //price
                                JSONObject price = obj.getJSONObject("prices");
                                Double normal_price = price.getDouble("normal_price");
                                tanga.setPrice(normal_price);

                                //Url
                                String productUrl = obj.getString("url");
                                tanga.setProductUrl(productUrl);

                                Double msrpPrice = price.getDouble("msrp");
                                tanga.setMsrpPrice(msrpPrice);

                                JSONArray jArray = obj.getJSONArray("images");
                                //if we want all of the images then need a for loop
                                String url = jArray.getJSONObject(0).getString("url");
                                tanga.setThumbnailUrl(url);

                                // adding tanga to tangas array
                                tangaList.add(tanga);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        // notifying list adapter about data changes
                        // so that it renders the list view with updated data
                        adapter.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error: ");

            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(tangaReq);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String productUrl = ((TextView) view.findViewById(R.id.productUrl)).getText().toString();

                Intent intent = new Intent(getActivity(), Details.class);

                intent.putExtra(Title2, productUrl);

                startActivity(intent);
            }
        });

    }


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tabs, container, false);

        return v;
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}