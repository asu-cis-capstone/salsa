package com.example.mariogp18.tanga.model;

/**
 * Created by mariogp18 on 11/4/15.
 */
public class Tanga {
    private String name;
    private String thumbnailUrl;
    private Double price;
    private Double msrpPrice;
    String productUrl;

    public Tanga() {
    }

    public Tanga(String name, Double price, Double msrpPrice, String thumbnailUrl, String productUrl) {
        this.name = name;
        this.thumbnailUrl = thumbnailUrl;
        this.price = price;
        this.msrpPrice= msrpPrice;
        this.productUrl = productUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getMsrpPrice() {
        return msrpPrice;
    }

    public void setMsrpPrice(Double msrpPrice) {
        this.msrpPrice = msrpPrice;
    }

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }
}