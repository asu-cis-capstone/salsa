package com.example.mariogp18.tanga;

import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Created by mariogp18 on 10/18/15.
 *
 * ***THERE ARE MANY TUTORIALS ON HOW TO MAKE A SLIDING TAB APP***
 *
 * In the main activity, everything is called/created. The main activity is used to set the number of tabs
 * and the titles for those tabs.
 *
 * You need to have one class per tab.
 *
 * SlidingTabLayout and SlidingTabStrip are given by Android.com.
 * These two files are samples to get the sliding tab.
 * https://developer.android.com/samples/SlidingTabsBasic/src/com.example.android.common/view/SlidingTabLayout.html
 * https://developer.android.com/samples/SlidingTabsBasic/src/com.example.android.common/view/SlidingTabStrip.html
 *
 * For the SlidingTabLayout I did add a section of the code. The public void onPageScrollStateChanged(int state)
 * was replaced with this class: private class InternalViewPagerListener implements ViewPager.OnPageChangeListener
 * This allows the last tab to return back to the first tab after sliding the last one
 * The old code is comment out. The line number is 254-273
 *
 * ViewPager sets the position of each tab. If you add one tab you have to add another elseif statement or
 * if you want to remove one you remove one else or elseif.
 *
 * RES-->COLOR--> selector.xml
 *Used to change the color of the states of the menu!!!!! Also the fourth one item
 * is to determine the color of the text of the menu when it is not highlighted/picked!
 *
 *RES-->Layout
 *Contains all of the layouts of the app. It uses XML which is similar to html
 *  activity_main.xml is the main layout
 *  tool_bar.xml contains the toolbar for the menu
 *  tab_X contains the layout for all of the tabs
 *
 *RES-->menu
 * Contains a file to remove an error that I was having.
 *
 * RES->values->colors.xml
 *
 *Android Manifest
 * The manifest file presents essential information about your app to the Android system,
 * information the system must have before it can run any of the app's code. For example, you allow
 * access to the Internet here.
 */
public class MainActivity extends ActionBarActivity {

    // Declaring Your View and Variables

    Toolbar toolbar;
    ViewPager pager;
    ViewPagerAdapter adapter;
    SlidingTabLayout tabs;
    //adds the menu tab titles
    CharSequence Titles[]={"Daily Deals","Men", "Women", "Electronics", "Home", "Clearance", "Apple Sale", "Top Sellers"};
    //Number of tabs based on the number of elements in array
    int Numboftabs =8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Creating The Toolbar and setting it as the Toolbar for the activity

        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);


        // Creating The ViewPagerAdapter and Passing Fragment Manager, Titles fot the Tabs and Number Of Tabs.
        adapter =  new ViewPagerAdapter(getSupportFragmentManager(),Titles,Numboftabs);

        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) findViewById(R.id.tabs);
        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width

        // Setting Custom Color for the Scroll bar indicator of the Tab View
        tabs.setCustomTabColorizer(new SlidingTabLayout.TabColorizer() {
            @Override
            public int getIndicatorColor(int position) {
                return getResources().getColor(R.color.tabsScrollColor);
            }
        });

        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
