package com.example.mariogp18.tanga;

/**
 * Created by mariogp18 on 10/18/15.
 */
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    CharSequence Titles[]; // This will Store the Titles of the Tabs which are Going to be passed when ViewPagerAdapter is created
    int NumbOfTabs; // Store the number of tabs, this will also be passed when the ViewPagerAdapter is created


    // Build a Constructor and assign the passed Values to appropriate values in the class
    public ViewPagerAdapter(FragmentManager fm,CharSequence mTitles[], int mNumbOfTabsumb) {
        super(fm);

        this.Titles = mTitles;
        this.NumbOfTabs = mNumbOfTabsumb;

    }

    //This method return the fragment for the every position in the View Pager
    @Override
    public Fragment getItem(int position) {

        if(position == 0) // if the position is 0 we are returning the First tab
        {
            Tab1 tab1 = new Tab1();
            return tab1;
        }
        else if(position ==1)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab2 tab2 = new Tab2();
            return tab2;
        }
        else if(position ==2)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab3 tab3 = new Tab3();
            return tab3;
        }
        else if(position ==3)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            SlidingTabStrip.Tab4 tab4 = new SlidingTabStrip.Tab4();
            return tab4;
        }
        else if(position ==4)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab5 tab5 = new Tab5();
            return tab5;
        }
        else if(position ==5)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab6 tab6 = new Tab6();
            return tab6;
        }
        else if(position ==6)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab7 tab7 = new Tab7();
            return tab7;
        }
        else if(position ==7)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab8 tab8 = new Tab8();
            return tab8;
        }
        else if(position ==8)             // As we are having 8 tabs if the position is now 0 it must be 1 so we are returning second tab
        {
            Tab9 tab9 = new Tab9();
            return tab9;
        }
        else             // As we are having 2 tabs if the position is now 1 it must be 2 so we are returning second tab
        {
            Tab10 tab10 = new Tab10();
            return tab10;
        }



    }

    // This method return the titles for the Tabs in the Tab Strip

    @Override
    public CharSequence getPageTitle(int position) {
        return Titles[position];
    }

    // This method return the Number of tabs for the tabs Strip

    @Override
    public int getCount() {
        return NumbOfTabs;
    }
}
